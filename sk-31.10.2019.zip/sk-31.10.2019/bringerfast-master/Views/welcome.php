<?php
echo"<h1 style='text-align: center'>WELCOME</h1>";