<!-- Author: Saravana kumar.N
Description: User Dashboard 
Dated: 25/10/2019 -->

<!DOCTYPE html>
<html>
<head>
	<title>Movie Ticket Booking System</title>
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/style.css">
	<link rel="stylesheet" type="text/javascript" href="../Assets/backend/js/selectseats.js">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	 <!--  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
	  <!-- carousel link -->
	   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	 

</head>
<body>
	<div class="container-fluid">
		<div class="row">
		<nav class="navbar navbar-inverse navbar-static-top">
									<!-- navbar starts here -->
		  	<div class="container-fluid">
		   		<div class="navbar-header">
			      	<a class="navbar-brand" href="#"><img src="../Assets/backend/images/logoct.png"></a>
			      	<span class="searchbar text-center">
			      	<input type="text" name="" class="searchbar" value="" placeholder="search movies"></span>
			      	<span class="search-btn"><button class="btn search-btn"><span class="glyphicon glyphicon-search "></span></button></span>
		    	</div>
			    <ul class="nav navbar-nav navbar-right">
			      <li class="active"><a href="#">Home</a></li>
			      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Languages <span class="caret"></span></a>
			        <ul class="dropdown-menu">
			          <li><a href="#" class="active">Tamil</a></li>
			          <li><a href="#">English</a></li>
			          <li><a href="#">Hindi</a></li>
			        </ul>
			      </li>
			      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Location <span class="caret"></span></a>
			        <ul class="dropdown-menu">
			          <li><a href="<?php echo baseURL().'/chennai_movies'?>">Chennai</a></li>
			          <li><a href="#">Vellore</a></li>
			          <li><a href="#">kancheepuram</a></li>
			        </ul>
			      </li>
			  </ul>
			      
			      
			</div>

		</nav>				<!-- navbar ends here  -->   <!-- navbar ends here  -->
	</div>

    <div class="container">
	 
	  <div id="myCarousel" class="carousel slide" data-ride="carousel">
	    <!-- Indicators -->
	    <ol class="carousel-indicators">
	      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
	      <li data-target="#myCarousel" data-slide-to="1"></li>
	      <li data-target="#myCarousel" data-slide-to="2"></li>
	    </ol>

	    <!-- Wrapper for slides -->
	    <div class="carousel-inner">
	      <div class="item active">
	      	<figure>
	      		<a href="#">
	        <img src="../Assets/backend/images/bigil4.jpg" alt="BIGIL" style="width:100%;">
	    		</a>
	        </figure>
	      </div>


	      <div class="item"><a href="#">
	        <img src="../Assets/backend/images/kaithi2.jpg" alt="KAITHI" style="width:100%;">
	    	</a>
	      </div>
	    
	      <div class="item"><a href="#">
	        <img src="../Assets/backend/images/asuranland.jpg" alt="ASURAN" style="width:100%;">
	        </a>
	      </div>
	    </div>

	    <!-- Left and right controls -->
	    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
	      <span class="glyphicon glyphicon-chevron-left"></span>
	      <span class="sr-only">Previous</span>
	    </a>
	    <a class="right carousel-control" href="#myCarousel" data-slide="next">
	      <span class="glyphicon glyphicon-chevron-right"></span>
	      <span class="sr-only">Next</span>
	    </a>
	  </div>
	</div>
	</div>  <!-- suspected div for reference -->
	<div class="row text-center">
		<h1>Movies Running Now </h1>
	</div>
	<div class="row ">
		<div class="col-md-3">
			<div class="card card-class"><a href="#">
			  <img src="../Assets/backend/images/bigil2.jpg" class="image-class" alt="Avatar">
			  <div class="">
			  	<h4><b>BIGIL</b></h4>
			    <p>U/A ACTION</p>
			    <!-- <div> <button class="btn-submit">Book</button> </div>  -->
			  </div></a>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card card-class"><a href="#">
			  <img src="../Assets/backend/images/kaithi.jpg" class="image-class" alt="Avatar" >
			  <div class="">
			  	<h4><b>KAITHI</b></h4>
			    <p>U/A ACTION</p> 
			    <!-- <div> <button class="btn-submit">Book</button> </div> -->
			  </div></a>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card card-class"><a href="#">
			  <img src="../Assets/backend/images/ARUVAM.jpg" class="image-class" alt="Avatar" >
			  <div class="">
			    <h4><b>ARUVAM</b></h4>
			    <!-- <div> <button class="btn-submit">Book</button> </div> -->
			    <p>U/A ACTION</p> 
			  </div></a>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card card-class"><a href="#">
			  <img src="../Assets/backend/images/joker.jpg" class="image-class" alt="Avatar" >
			  <div class="">
			  	<h4><b>JOKER</b></h4> 
			    <p>U/A ACTION</p> 
			    <!-- <div> <button class="btn-submit">Book</button> </div> -->
			  </div></a>
			</div>
		</div>
	</div> <br/> <br/> <br/>
	<div class="row ">
		<div class="col-md-3">
			<div class="card card-class"><a href="#">
			  <img src="../Assets/backend/images/houseful.jpg" class="image-class" alt="Avatar">
			  <div class="">
			  	<h4><b>Housefull-4</b></h4>
			    <p>U/A DRAMA</p>
			    <!-- <div> <button class="btn-submit">Book</button> </div>  -->
			  </div></a>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card card-class"><a href="#">
			  <img src="../Assets/backend/images/kaithi.jpg" class="image-class" alt="Avatar" >
			  <div class="">
			  	<h4><b>KAITHI</b></h4>
			    <p>U/A ACTION</p> 
			    <!-- <div> <button class="btn-submit">Book</button> </div> -->
			  </div></a>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card card-class"><a href="#">
			  <img src="../Assets/backend/images/ARUVAM.jpg" class="image-class" alt="Avatar" >
			  <div class="">
			    <h4><b>ARUVAM</b></h4>
			    <!-- <div> <button class="btn-submit">Book</button> </div> -->
			    <p>U/A ACTION</p> 
			  </div></a>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card card-class"><a href="#">
			  <img src="../Assets/backend/images/joker.jpg" class="image-class" alt="Avatar" >
			  <div class="">
			  	<h4><b>JOKER</b></h4> 
			    <p>U/A ACTION</p> 
			    <!-- <div> <button class="btn-submit">Book</button> </div> -->
			  </div></a>
			</div>
		</div>
	</div>
	<div class="row">
	</div>

<footer>
<div class="row text-center">
  <hr>
  <img src="../Assets/backend/images/logoct.png">
  <hr>
</div>
</footer>
	


	




















		
	</div>
</body>
</html>

