<!-- Author: Saravana kumar.N
Desription: Registration page for New User
Dated: 22/10/2019 -->

<!DOCTYPE html>
<html>
<head>
	<title>Movie Ticket Booking System</title>
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	 

</head>
<body>
	<div class="container-fluid">
						<!-- main container starts here -->
		<div class="row">
		<nav class="navbar navbar-inverse navbar-static-top">
									<!-- navbar starts here -->
		  	<div class="container-fluid">
		   		<div class="navbar-header">
			      	<a class="navbar-brand" href="#"><img src="../Assets/backend/images/logoct.png"></a>
			      	<span class="searchbar text-center">
			      	<input type="text" name="" class="searchbar" value="" placeholder="search movies"></span>
			      	<span class="search-btn"><button class="btn search-btn"><span class="glyphicon glyphicon-search "></span></button></span>
		    	</div>
			    <ul class="nav navbar-nav navbar-right">
			      <li class="active"><a href="#">Home</a></li>
			      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Languages <span class="caret"></span></a>
			        <ul class="dropdown-menu">
			          <li><a href="#" class="active">Tamil</a></li>
			          <li><a href="#">English</a></li>
			          <li><a href="#">Hindi</a></li>
			        </ul>
			      </li>
			      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Location <span class="caret"></span></a>
			        <ul class="dropdown-menu">
			          <li><a href="chennai_movies.php">Chennai</a></li>
			          <li><a href="#">Vellore</a></li>
			          <li><a href="#">kancheepuram</a></li>
			        </ul>
			      </li>
			      
			      <li>
			      	<div class="container-m menu-icon dropbtn" onclick="myFunction(this)" >
	  					<div class="bar1"></div>
	  					<div class="bar2"></div>
	  					<div class="bar3"></div>
					</div>
					
			      </li>
			    </ul>
			    <div id="myDropdown" class="dropdown-content">
					    <a href="#home">Home</a>
					    <a href="#about"><span class="glyphicon glyphicon-cog">Settings </span> </a>
					    <a href="#contact">Contact</a>
				</div>
			</div>

		</nav>				<!-- navbar ends here  -->
		</div>
		<div class="row text-center">
			<h1> SIGN UP HERE!!!</h1>
		</div>
		<div class="row">
			<div class="col-md-3">
			</div>
			<div class="col-md-6 shadow text-center signup-head">
			<!-- 	<div class=" row text-center signup-head">
					<h3> New User Registration </h3>
				</div> -->
				<form class=" " method="POST" action="">
					<label>First Name</label>
					<input type="text" class="formip text-center" name="fname" placeholder="Enter Your First Name">
					<label>Last Name</label>
					<input type="text" class="formip text-center" name="lname" placeholder="Enter Your Last Name">
					<label>Email Address</label>
					<input type="text" class="formip text-center" name="fname" placeholder="Enter Your Email">
					<label>Password</label>
					<input type="password" class="formip text-center" name="fname" placeholder="Enter Your Password">
					<label>Re-Enter Password</label>
					<input type="password" class="formip text-center" name="fname" placeholder="Re-Enter Your Password">
					<label>Mobile Number</label>
					<input type="text" class="formip text-center" name="fname" placeholder="Enter Your Mobile Number">
					
					<br>
					<input type="submit" name="submit" value="Submit" class="btn btn-success">
					<input type="button" name="cancel" value="Cancel" class="btn btn-danger">
										<br>
			</div>
			<div class="col-md-3">
			</div>
		</form>
	</div>
			

		










	</div>
	 <script>
			function menu(x) {
			  x.classList.toggle("change");
			  document.getElementById("myDropdown").classList.toggle("show");




			}
							/* When the user clicks on the button, 
				toggle between hiding and showing the dropdown content */
			function myFunction(x) {
							  x.classList.toggle("change");

			  document.getElementById("myDropdown").classList.toggle("show");
			}
			// Close the dropdown if the user clicks outside of it
				window.onclick = function(event) {

				  if (!event.target.matches('.dropbtn')) {
				    var dropdowns = document.getElementsByClassName("dropdown-content");
				    var i;
				    for (i = 0; i < dropdowns.length; i++) {
				      var openDropdown = dropdowns[i];
				      if (openDropdown.classList.contains('show')) {

				        openDropdown.classList.remove('show');

				        menu(x);
				      }
				    }
				  }
				}


	</script>	

</body>

</html>