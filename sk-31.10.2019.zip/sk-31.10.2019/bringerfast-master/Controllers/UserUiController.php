<?php

// Author:saravana
// Description: userinterface controllers

namespace Controllers;

use Request\Request;
use Models\Movie;

class UserUiController{

	public function chennaiMovies(){


		// view('chennaiMovies.php');
		try{

			$movies = Movie::all();
			export('chennaiMovies',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}


	}
	public function bigil()
	{
		#code....

		view('bigil.php');
	}

}